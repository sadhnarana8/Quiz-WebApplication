const myQuiz = [
    {
        question: "Q1: The tree which sends down roots from its branches to the soil is:",
        a: "Oak",
        b: "Pine",
        c: "Banyan",
        d: "Palm",
        ans: "ans3"
    },
    {
        question: "Q2: Electric Bulb filament is made up of?",
        a: "Copper",
        b: "Aluminium",
        c: "Lead",
        d: "Tungsten",
        ans: "ans4"
    },
    {
        question: "Q3: Brass gets discoloured in air because of the presence of which?",
        a: "Oxygen",
        b: "Hydrogen Sulphide",
        c: "Carbon dioxide",
        d: "Nitrogen",
        ans: "ans2"
    },
     {
         question: "Q4: Which of the following non-metal remains liquid at room temperature?",
        a: "Phosphorus",
        b: "Bromine",
        c: "Chlorine",
        d: "Helium",
        ans: "ans2"
    },
    {
        question: "Q5: Bromine is a:",
        a: "Black Solid",
        b: "Red Liquid",
        c: "Colourless Gas",
        d: "Highly Inflammable Gas",
        ans: "ans2"
    },
    {
        question: "Q6: The hardest substance available on earth is:",
        a: "Gold",
        b: "Iron",
        c: "Diamond",
        d: "Platinum",
        ans: "ans3"
    },
    {
        question: "Q7: Which of the following is used as lubricant?",
        a: "Graphite",
        b: "Silica",
        c: "Iron Oxide",
        d: "Diamond",
        ans: "ans1"
    },
    {
        question: "Q8: Air is an:",
        a: "Compound",
        b: "Element",
        c: "Electrolyte",
        d: "Mixture",
        ans: "ans4"
    },
    {
        question: "Q9: Baloons are filled with:",
        a: "Nitrogen",
        b: "Hilium",
        c: "Oxygen",
        d: "Argon",
        ans: "ans2"
    },
    {
        question: "Q10: Which of the following is the lightest metal?",
        a: "Mercury",
        b: "Lithium",
        c: "Lead",
        d: "Silver",
        ans: "ans2"
    },
];

const question = document.getElementById('question');
const option1 = document.getElementById('option1');
const option2 = document.getElementById('option2');
const option3 = document.getElementById('option3');
const option4 = document.getElementById('option4');
const submit = document.getElementById('submit');
const answers = document.querySelectorAll('.answer');
const showScore = document.querySelector('#showScore');


let questionCount = 0;
let score = 0;

function play(){
let sound =  new Audio("wemida-waiting-for-the-end-quizzing-voting-background-music-16575.mp3");
 sound.play();
}                   //audio is stored in it

play();             //called audio vala function


function chosenAnswer(){                //sound for an answer
 let sound2 = new Audio("correct-6033.mp3");
 sound2.chosenAnswer();
}


loadQues();
function loadQues(){
showScore.innerHTML = `<h3>Score: ${score}/${myQuiz.length}</h3>`;
    deselectAnswer();
    const questioList = myQuiz[questionCount];     //entire array get stored in this variable
    question.innerText = questioList.question;
    option1.innerText = questioList.a;
    option2.innerText = questioList.b;
    option3.innerText = questioList.c;
    option4.innerText = questioList.d;
}

function deselectAnswer(){                         //for deselecting previous options
    answers.forEach(currentElem => currentElem.checked=false)
}
let getAnswer = () => {
let answer;
answers.forEach(currentElem =>{
    if(currentElem.checked){
       answer = currentElem.id;
    }
    
});
// console.log(answer);                 //print answer (chosen)
return answer;
};

submit.addEventListener('click',() => {
    const checkAns = getAnswer();
    console.log(checkAns);
     if(checkAns){
    if(checkAns === myQuiz[questionCount].ans){
        score++;
        }
// showScore.innerHTML = `<h3>Score is ${score}/${myQuiz.length}</h3>`;

    questionCount++;
    // finalScore();
    if(questionCount < myQuiz.length){
        loadQues();
    }
    else{
        finalScore();
    }
}
});

function finalScore(){
    showScore.innerHTML = `
        <h3>You Scored: ${score}/${myQuiz.length} ✌ </h3>
        <button class ="btn" onclick = "location.reload()"> <b>Play Again<b> </button>`;
        showScore.classList.remove('scoreArea') ;}